# Installation

1. Download and install wordpress
2. Install WooCommerce
3. Navigate to `wp-content/plugins` folder
```bash
cd wp-content/plugins
```
4. Git clone this repository to the folder
```bash
git clone https://github.com/RevenueMonster/woocommerce-revenuemonster-payment-gateway.git
```
5. Hooray, you have completed the steps